<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users_article extends Model
{
    //
}
